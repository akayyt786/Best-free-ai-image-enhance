
import React, { useState, useCallback } from 'react';
import { Header } from './components/Header';
import { ImageUploader } from './components/ImageUploader';
import { ImageComparator } from './components/ImageComparator';
import { enhanceImage } from './services/geminiService';
import { fileToDataURL, fileToBase64 } from './utils/imageUtils';
import type { ImageState } from './types';

const App: React.FC = () => {
  const [originalImage, setOriginalImage] = useState<ImageState | null>(null);
  const [enhancedImage, setEnhancedImage] = useState<ImageState | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleImageUpload = useCallback(async (file: File) => {
    setIsLoading(true);
    setError(null);
    setEnhancedImage(null);

    try {
      const dataUrl = await fileToDataURL(file);
      setOriginalImage({ url: dataUrl, name: file.name });

      const base64Image = await fileToBase64(file);
      const enhancedBase64 = await enhanceImage(base64Image, file.type);
      
      const enhancedDataUrl = `data:image/png;base64,${enhancedBase64}`;
      setEnhancedImage({ url: enhancedDataUrl, name: `Enhanced - ${file.name}` });

    } catch (err) {
      console.error(err);
      setError('Failed to enhance the image. Please try another one.');
      setOriginalImage(null);
    } finally {
      setIsLoading(false);
    }
  }, []);
  
  const handleReset = useCallback(() => {
    setOriginalImage(null);
    setEnhancedImage(null);
    setError(null);
    setIsLoading(false);
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col items-center p-4 sm:p-6 lg:p-8">
      <Header />
      <main className="w-full max-w-7xl mx-auto flex-grow flex flex-col items-center">
        {error && (
          <div className="bg-red-900 border border-red-700 text-red-200 px-4 py-3 rounded-lg relative mb-6 w-full max-w-4xl text-center" role="alert">
            <strong className="font-bold">Error: </strong>
            <span className="block sm:inline">{error}</span>
          </div>
        )}
        
        {!originalImage && !isLoading && (
          <ImageUploader onImageUpload={handleImageUpload} disabled={isLoading} />
        )}

        {(isLoading || originalImage) && (
           <ImageComparator 
            originalImage={originalImage}
            enhancedImage={enhancedImage}
            isLoading={isLoading}
            onReset={handleReset}
          />
        )}
      </main>
      <footer className="w-full max-w-7xl mx-auto text-center py-6">
        <p className="text-gray-500 text-sm">Powered by Gemini API</p>
      </footer>
    </div>
  );
};

export default App;
