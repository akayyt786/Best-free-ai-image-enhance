import { GoogleGenAI, Modality } from '@google/genai';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const ENHANCEMENT_PROMPT = `
Your task is to perform an extreme and masterful enhancement of this image. The goal is to transform it from its current state into a hyper-realistic, crystal-clear masterpiece that looks like it was shot on a high-end professional camera in 8K resolution.

- **DEBLUR AND SHARPEN:** This is the most critical step. Aggressively remove all blurriness, motion blur, and lack of focus. Reconstruct fine details with forensic precision. The final image must be razor-sharp from edge to edge.
- **UPSCALE AND REFINE:** Increase the perceived resolution of the image. Add texture and micro-details that were lost or not present in the original.
- **COLOR AND CONTRAST MASTERY:** Create breathtaking color depth and vibrancy. The colors should pop with life. Push the dynamic range to its absolute limit, with deep, rich blacks and brilliant, clean highlights.
- **PERFECT LIGHTING:** Re-light the scene to create a dramatic, cinematic, and three-dimensional feel. Sculpt the subjects with light.
- **NOISE OBLITERATION:** Eliminate 100% of digital noise, grain, and artifacts. The result must be impeccably clean.

The final output must be ONLY the enhanced image, nothing else. The difference between the original and the enhanced version should be night and day.
`;

export const enhanceImage = async (base64ImageData: string, mimeType: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image-preview',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64ImageData,
              mimeType: mimeType,
            },
          },
          {
            text: ENHANCEMENT_PROMPT,
          },
        ],
      },
      config: {
        responseModalities: [Modality.IMAGE, Modality.TEXT],
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return part.inlineData.data;
      }
    }
    
    // If no image is returned, check if there's a text response explaining why
    const textResponse = response.text;
    if (textResponse) {
      throw new Error(`API returned a text response instead of an image: ${textResponse}`);
    }

    throw new Error('No image data found in the API response.');

  } catch (error) {
    console.error('Error enhancing image with Gemini API:', error);
    throw new Error('Failed to communicate with the image enhancement service.');
  }
};