
export interface ImageState {
  url: string;
  name: string;
}
