
import React from 'react';
import type { ImageState } from '../types';
import { Spinner } from './Spinner';

interface ImageComparatorProps {
  originalImage: ImageState | null;
  enhancedImage: ImageState | null;
  isLoading: boolean;
  onReset: () => void;
}

const ImageCard: React.FC<{ title: string; image: ImageState | null; children?: React.ReactNode }> = ({ title, image, children }) => (
  <div className="flex flex-col items-center w-full bg-gray-800 p-4 rounded-xl shadow-lg">
    <h3 className="text-xl font-semibold mb-4 text-gray-300">{title}</h3>
    <div className="w-full aspect-square rounded-lg bg-gray-900 flex items-center justify-center overflow-hidden">
      {image ? (
        <img src={image.url} alt={image.name} className="w-full h-full object-contain" />
      ) : (
        children
      )}
    </div>
    {image && <p className="text-xs text-gray-500 mt-2 truncate w-full text-center">{image.name}</p>}
  </div>
);

export const ImageComparator: React.FC<ImageComparatorProps> = ({ originalImage, enhancedImage, isLoading, onReset }) => {
  return (
    <div className="w-full max-w-6xl p-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
        <ImageCard title="Original" image={originalImage}>
           {isLoading && <Spinner text="Uploading..." />}
        </ImageCard>
        <ImageCard title="Enhanced" image={enhancedImage}>
          {isLoading && <Spinner text="Enhancing Image..." />}
          {!isLoading && !enhancedImage && <div className="text-gray-500">Enhanced image will appear here</div>}
        </ImageCard>
      </div>
       <div className="mt-8 text-center">
        <button
          onClick={onReset}
          disabled={isLoading}
          className="bg-blue-600 text-white font-semibold py-2 px-6 rounded-lg hover:bg-blue-700 transition-colors duration-300 disabled:bg-gray-500 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-900 focus:ring-blue-500"
        >
          {isLoading ? 'Processing...' : 'Enhance Another Image'}
        </button>
      </div>
    </div>
  );
};
