
import React from 'react';
import { PhotoIcon } from './Icon';

export const Header: React.FC = () => {
  return (
    <header className="w-full max-w-7xl mx-auto text-center py-8 mb-8">
      <div className="flex justify-center items-center gap-4">
        <PhotoIcon className="w-12 h-12 text-blue-400"/>
        <h1 className="text-4xl sm:text-5xl font-bold tracking-tight bg-gradient-to-r from-blue-400 to-teal-300 text-transparent bg-clip-text">
          AI Image Enhancer
        </h1>
      </div>
      <p className="mt-4 text-lg text-gray-400 max-w-2xl mx-auto">
        Upload an image to automatically improve its quality, sharpness, and color vibrancy using AI.
      </p>
    </header>
  );
};
